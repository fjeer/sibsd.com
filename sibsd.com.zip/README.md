# Sistem Bank Sampah Digital
dibuat untuk memenuhi tugas UTS mata kuliah pemrograman aplikasi berbasis website

membuat aplikasi sistem bank sampah digital dengan menggunakan php native bootstrap dan Java Script

ikuti saya di github : https://github.com/fjeer instagram : https://instagram.com/jer.seven linkedin : https://linkedin.com/in/fjeer
